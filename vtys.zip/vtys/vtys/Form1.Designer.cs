﻿namespace vtys
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonsayi = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.buttonlist = new System.Windows.Forms.Button();
            this.textBoxurtmyil = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxrenk = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxplaka = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxmdl = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxmarka = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxknmid = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxkm = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxarbturid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxarbno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonara = new System.Windows.Forms.Button();
            this.buttongnclle = new System.Windows.Forms.Button();
            this.buttonsil = new System.Windows.Forms.Button();
            this.buttonekle = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonekpmnsayi = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.buttonekpmnlist = new System.Windows.Forms.Button();
            this.textBoxekpmnknm = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxekpmnturid = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxekpmnad = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxekpmnno = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.buttonekpmnara = new System.Windows.Forms.Button();
            this.buttonekpmngnclle = new System.Windows.Forms.Button();
            this.buttonekpmnsil = new System.Windows.Forms.Button();
            this.buttonekpmnekle = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(798, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Turquoise;
            this.tabPage1.Controls.Add(this.buttonsayi);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.Controls.Add(this.buttonlist);
            this.tabPage1.Controls.Add(this.textBoxurtmyil);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.textBoxrenk);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textBoxplaka);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.textBoxmdl);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.textBoxmarka);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.textBoxknmid);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.textBoxkm);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textBoxarbturid);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.textBoxarbno);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.buttonara);
            this.tabPage1.Controls.Add(this.buttongnclle);
            this.tabPage1.Controls.Add(this.buttonsil);
            this.tabPage1.Controls.Add(this.buttonekle);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(790, 422);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Arabalar";
            // 
            // buttonsayi
            // 
            this.buttonsayi.Location = new System.Drawing.Point(659, 112);
            this.buttonsayi.Name = "buttonsayi";
            this.buttonsayi.Size = new System.Drawing.Size(82, 23);
            this.buttonsayi.TabIndex = 25;
            this.buttonsayi.Text = "Sayı";
            this.buttonsayi.UseVisualStyleBackColor = true;
            this.buttonsayi.Click += new System.EventHandler(this.buttonsayi_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.Location = new System.Drawing.Point(637, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 25;
            this.dataGridView2.Size = new System.Drawing.Size(125, 84);
            this.dataGridView2.TabIndex = 24;
            // 
            // buttonlist
            // 
            this.buttonlist.Location = new System.Drawing.Point(531, 314);
            this.buttonlist.Name = "buttonlist";
            this.buttonlist.Size = new System.Drawing.Size(75, 23);
            this.buttonlist.TabIndex = 23;
            this.buttonlist.Text = "Listele";
            this.buttonlist.UseVisualStyleBackColor = true;
            this.buttonlist.Click += new System.EventHandler(this.buttonlist_Click);
            // 
            // textBoxurtmyil
            // 
            this.textBoxurtmyil.Location = new System.Drawing.Point(301, 290);
            this.textBoxurtmyil.Name = "textBoxurtmyil";
            this.textBoxurtmyil.Size = new System.Drawing.Size(100, 23);
            this.textBoxurtmyil.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(235, 293);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 15);
            this.label9.TabIndex = 21;
            this.label9.Text = "Üretim Yılı:";
            // 
            // textBoxrenk
            // 
            this.textBoxrenk.Location = new System.Drawing.Point(301, 260);
            this.textBoxrenk.Name = "textBoxrenk";
            this.textBoxrenk.Size = new System.Drawing.Size(100, 23);
            this.textBoxrenk.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(235, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 15);
            this.label5.TabIndex = 19;
            this.label5.Text = "Renk:";
            // 
            // textBoxplaka
            // 
            this.textBoxplaka.Location = new System.Drawing.Point(301, 231);
            this.textBoxplaka.Name = "textBoxplaka";
            this.textBoxplaka.Size = new System.Drawing.Size(100, 23);
            this.textBoxplaka.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(235, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "Plaka:";
            // 
            // textBoxmdl
            // 
            this.textBoxmdl.Location = new System.Drawing.Point(301, 201);
            this.textBoxmdl.Name = "textBoxmdl";
            this.textBoxmdl.Size = new System.Drawing.Size(100, 23);
            this.textBoxmdl.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(235, 204);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "Model:";
            // 
            // textBoxmarka
            // 
            this.textBoxmarka.Location = new System.Drawing.Point(109, 319);
            this.textBoxmarka.Name = "textBoxmarka";
            this.textBoxmarka.Size = new System.Drawing.Size(100, 23);
            this.textBoxmarka.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(43, 322);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "Marka:";
            // 
            // textBoxknmid
            // 
            this.textBoxknmid.Location = new System.Drawing.Point(109, 290);
            this.textBoxknmid.Name = "textBoxknmid";
            this.textBoxknmid.Size = new System.Drawing.Size(100, 23);
            this.textBoxknmid.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "Konum ID:";
            // 
            // textBoxkm
            // 
            this.textBoxkm.Location = new System.Drawing.Point(109, 261);
            this.textBoxkm.Name = "textBoxkm";
            this.textBoxkm.Size = new System.Drawing.Size(100, 23);
            this.textBoxkm.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Kilometre:";
            // 
            // textBoxarbturid
            // 
            this.textBoxarbturid.Location = new System.Drawing.Point(109, 231);
            this.textBoxarbturid.Name = "textBoxarbturid";
            this.textBoxarbturid.Size = new System.Drawing.Size(100, 23);
            this.textBoxarbturid.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "ArabaTur ID:";
            // 
            // textBoxarbno
            // 
            this.textBoxarbno.Location = new System.Drawing.Point(109, 202);
            this.textBoxarbno.Name = "textBoxarbno";
            this.textBoxarbno.Size = new System.Drawing.Size(100, 23);
            this.textBoxarbno.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 205);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Araba No:";
            // 
            // buttonara
            // 
            this.buttonara.Location = new System.Drawing.Point(601, 270);
            this.buttonara.Name = "buttonara";
            this.buttonara.Size = new System.Drawing.Size(75, 23);
            this.buttonara.TabIndex = 4;
            this.buttonara.Text = "Ara";
            this.buttonara.UseVisualStyleBackColor = true;
            this.buttonara.Click += new System.EventHandler(this.buttonara_Click);
            // 
            // buttongnclle
            // 
            this.buttongnclle.Location = new System.Drawing.Point(455, 270);
            this.buttongnclle.Name = "buttongnclle";
            this.buttongnclle.Size = new System.Drawing.Size(75, 23);
            this.buttongnclle.TabIndex = 3;
            this.buttongnclle.Text = "Güncelle";
            this.buttongnclle.UseVisualStyleBackColor = true;
            this.buttongnclle.Click += new System.EventHandler(this.buttongnclle_Click);
            // 
            // buttonsil
            // 
            this.buttonsil.Location = new System.Drawing.Point(601, 211);
            this.buttonsil.Name = "buttonsil";
            this.buttonsil.Size = new System.Drawing.Size(75, 23);
            this.buttonsil.TabIndex = 2;
            this.buttonsil.Text = "Sil";
            this.buttonsil.UseVisualStyleBackColor = true;
            this.buttonsil.Click += new System.EventHandler(this.buttonsil_Click);
            // 
            // buttonekle
            // 
            this.buttonekle.Location = new System.Drawing.Point(455, 214);
            this.buttonekle.Name = "buttonekle";
            this.buttonekle.Size = new System.Drawing.Size(75, 23);
            this.buttonekle.TabIndex = 1;
            this.buttonekle.Text = "Ekle";
            this.buttonekle.UseVisualStyleBackColor = true;
            this.buttonekle.Click += new System.EventHandler(this.buttonekle_Click);
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Location = new System.Drawing.Point(6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(616, 174);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Turquoise;
            this.tabPage2.Controls.Add(this.buttonekpmnsayi);
            this.tabPage2.Controls.Add(this.dataGridView3);
            this.tabPage2.Controls.Add(this.buttonekpmnlist);
            this.tabPage2.Controls.Add(this.textBoxekpmnknm);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.textBoxekpmnturid);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.textBoxekpmnad);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.textBoxekpmnno);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.buttonekpmnara);
            this.tabPage2.Controls.Add(this.buttonekpmngnclle);
            this.tabPage2.Controls.Add(this.buttonekpmnsil);
            this.tabPage2.Controls.Add(this.buttonekpmnekle);
            this.tabPage2.Controls.Add(this.dataGridView4);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(790, 422);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ekipman";
            // 
            // buttonekpmnsayi
            // 
            this.buttonekpmnsayi.Location = new System.Drawing.Point(656, 112);
            this.buttonekpmnsayi.Name = "buttonekpmnsayi";
            this.buttonekpmnsayi.Size = new System.Drawing.Size(82, 23);
            this.buttonekpmnsayi.TabIndex = 51;
            this.buttonekpmnsayi.Text = "Sayı";
            this.buttonekpmnsayi.UseVisualStyleBackColor = true;
            this.buttonekpmnsayi.Click += new System.EventHandler(this.buttonekpmnsayi_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView3.Location = new System.Drawing.Point(634, 6);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 25;
            this.dataGridView3.Size = new System.Drawing.Size(125, 84);
            this.dataGridView3.TabIndex = 50;
            // 
            // buttonekpmnlist
            // 
            this.buttonekpmnlist.Location = new System.Drawing.Point(528, 314);
            this.buttonekpmnlist.Name = "buttonekpmnlist";
            this.buttonekpmnlist.Size = new System.Drawing.Size(75, 23);
            this.buttonekpmnlist.TabIndex = 49;
            this.buttonekpmnlist.Text = "Listele";
            this.buttonekpmnlist.UseVisualStyleBackColor = true;
            this.buttonekpmnlist.Click += new System.EventHandler(this.buttonekpmnlist_Click);
            // 
            // textBoxekpmnknm
            // 
            this.textBoxekpmnknm.Location = new System.Drawing.Point(313, 293);
            this.textBoxekpmnknm.Name = "textBoxekpmnknm";
            this.textBoxekpmnknm.Size = new System.Drawing.Size(100, 23);
            this.textBoxekpmnknm.TabIndex = 38;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(247, 296);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 15);
            this.label15.TabIndex = 37;
            this.label15.Text = "Konum ID:";
            // 
            // textBoxekpmnturid
            // 
            this.textBoxekpmnturid.Location = new System.Drawing.Point(313, 240);
            this.textBoxekpmnturid.Name = "textBoxekpmnturid";
            this.textBoxekpmnturid.Size = new System.Drawing.Size(100, 23);
            this.textBoxekpmnturid.TabIndex = 36;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(223, 243);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(87, 15);
            this.label16.TabIndex = 35;
            this.label16.Text = "EkipmanTür ID:";
            // 
            // textBoxekpmnad
            // 
            this.textBoxekpmnad.Location = new System.Drawing.Point(106, 290);
            this.textBoxekpmnad.Name = "textBoxekpmnad";
            this.textBoxekpmnad.Size = new System.Drawing.Size(100, 23);
            this.textBoxekpmnad.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(29, 293);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 15);
            this.label17.TabIndex = 33;
            this.label17.Text = "Ekipman Ad:";
            // 
            // textBoxekpmnno
            // 
            this.textBoxekpmnno.Location = new System.Drawing.Point(106, 240);
            this.textBoxekpmnno.Name = "textBoxekpmnno";
            this.textBoxekpmnno.Size = new System.Drawing.Size(100, 23);
            this.textBoxekpmnno.TabIndex = 32;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(28, 243);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 15);
            this.label18.TabIndex = 31;
            this.label18.Text = "Ekipman No:";
            // 
            // buttonekpmnara
            // 
            this.buttonekpmnara.Location = new System.Drawing.Point(598, 270);
            this.buttonekpmnara.Name = "buttonekpmnara";
            this.buttonekpmnara.Size = new System.Drawing.Size(75, 23);
            this.buttonekpmnara.TabIndex = 30;
            this.buttonekpmnara.Text = "Ara";
            this.buttonekpmnara.UseVisualStyleBackColor = true;
            this.buttonekpmnara.Click += new System.EventHandler(this.buttonekpmnara_Click);
            // 
            // buttonekpmngnclle
            // 
            this.buttonekpmngnclle.Location = new System.Drawing.Point(452, 270);
            this.buttonekpmngnclle.Name = "buttonekpmngnclle";
            this.buttonekpmngnclle.Size = new System.Drawing.Size(75, 23);
            this.buttonekpmngnclle.TabIndex = 29;
            this.buttonekpmngnclle.Text = "Güncelle";
            this.buttonekpmngnclle.UseVisualStyleBackColor = true;
            this.buttonekpmngnclle.Click += new System.EventHandler(this.buttonekpmngnclle_Click);
            // 
            // buttonekpmnsil
            // 
            this.buttonekpmnsil.Location = new System.Drawing.Point(598, 211);
            this.buttonekpmnsil.Name = "buttonekpmnsil";
            this.buttonekpmnsil.Size = new System.Drawing.Size(75, 23);
            this.buttonekpmnsil.TabIndex = 28;
            this.buttonekpmnsil.Text = "Sil";
            this.buttonekpmnsil.UseVisualStyleBackColor = true;
            this.buttonekpmnsil.Click += new System.EventHandler(this.buttonekpmnsil_Click);
            // 
            // buttonekpmnekle
            // 
            this.buttonekpmnekle.Location = new System.Drawing.Point(452, 214);
            this.buttonekpmnekle.Name = "buttonekpmnekle";
            this.buttonekpmnekle.Size = new System.Drawing.Size(75, 23);
            this.buttonekpmnekle.TabIndex = 27;
            this.buttonekpmnekle.Text = "Ekle";
            this.buttonekpmnekle.UseVisualStyleBackColor = true;
            this.buttonekpmnekle.Click += new System.EventHandler(this.buttonekpmnekle_Click);
            // 
            // dataGridView4
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView4.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView4.Location = new System.Drawing.Point(3, 6);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 25;
            this.dataGridView4.Size = new System.Drawing.Size(616, 174);
            this.dataGridView4.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TextBox textBoxurtmyil;
        private Label label9;
        private TextBox textBoxrenk;
        private Label label5;
        private TextBox textBoxplaka;
        private Label label6;
        private TextBox textBoxmdl;
        private Label label7;
        private TextBox textBoxmarka;
        private Label label8;
        private TextBox textBoxknmid;
        private Label label3;
        private TextBox textBoxkm;
        private Label label4;
        private TextBox textBoxarbturid;
        private Label label2;
        private TextBox textBoxarbno;
        private Label label1;
        private Button buttonara;
        private Button buttongnclle;
        private Button buttonsil;
        private Button buttonekle;
        private DataGridView dataGridView1;
        private TabPage tabPage2;
        private Button buttonlist;
        private Button buttonsayi;
        private DataGridView dataGridView2;
        private Button buttonekpmnsayi;
        private DataGridView dataGridView3;
        private Button buttonekpmnlist;
        private TextBox textBoxekpmnknm;
        private Label label15;
        private TextBox textBoxekpmnturid;
        private Label label16;
        private TextBox textBoxekpmnad;
        private Label label17;
        private TextBox textBoxekpmnno;
        private Label label18;
        private Button buttonekpmnara;
        private Button buttonekpmngnclle;
        private Button buttonekpmnsil;
        private Button buttonekpmnekle;
        private DataGridView dataGridView4;
    }
}